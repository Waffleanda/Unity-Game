﻿namespace FishNet.Managing.Timing
{
    public enum TickType : byte
    {
        Tick = 0,
        LocalTick = 1,
        LastPacketTick = 2
    }

}