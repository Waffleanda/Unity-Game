﻿namespace FishNet.Managing.Object
{
    public enum SpawnParentType : byte
    {
        Unset = 0,
        NetworkObject = 1,
        NetworkBehaviour = 2
    }

}