﻿using FishNet.Object.Helping;

namespace FishNet.Object
{

    public enum DespawnType : byte
    {
        Destroy = 0,
        Pool = 1,
    }


}