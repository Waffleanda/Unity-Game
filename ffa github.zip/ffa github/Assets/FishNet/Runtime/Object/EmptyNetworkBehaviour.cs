﻿
namespace FishNet.Object
{
    /// <summary>
    /// This may be added at runtime to find objects without any network scripts, beneath a NetworkObject.
    /// </summary>
    public class EmptyNetworkBehaviour : NetworkBehaviour
    {

    }


}