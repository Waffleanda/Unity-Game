﻿using FishNet.Object.Helping;

namespace FishNet.Object
{
    [System.Flags]
    public enum PredictedSpawningType : byte
    {
        Disabled = 0,
        Spawn = 1,
        Despawn = 2,
    }


}