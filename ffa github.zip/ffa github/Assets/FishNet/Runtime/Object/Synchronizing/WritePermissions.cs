namespace FishNet.Object.Synchronizing
{
    /// <summary>
    /// Which clients or server may write updates.
    /// </summary>
    public enum WritePermission
    {
        ServerOnly
    }
}