﻿using MonoFN.Cecil;
using MonoFN.Cecil.Cil;
using System;
using System.Collections.Generic;

namespace FishNet.CodeGenerating.Helping
{
    public static class Instructions
    {
    }

}